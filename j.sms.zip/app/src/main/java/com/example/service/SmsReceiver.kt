package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.model.Conversation
import com.example.data.model.Message
import com.example.data.model.MessageStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            if (!messages.isNullOrEmpty()) {
                val db = AppDatabase.getInstance(context)
                val scope = CoroutineScope(Dispatchers.IO)
                scope.launch {
                    val fullBody = StringBuilder()
                    var sender = ""
                    var timestamp = System.currentTimeMillis()

                    for (sms in messages) {
                        sender = sms.originatingAddress ?: "Unknown"
                        fullBody.append(sms.messageBody)
                        timestamp = sms.timestampMillis
                    }

                    val bodyStr = fullBody.toString()

                    // Find or create conversation
                    var conversation = db.conversationDao().getConversationByAddress(sender)
                    val convId = if (conversation == null) {
                        val newConv = Conversation(
                            address = sender,
                            contactName = sender,
                            lastMessage = bodyStr,
                            timestamp = timestamp,
                            unreadCount = 1,
                            avatarColorHex = getAvatarColorForName(sender)
                        )
                        db.conversationDao().insertConversation(newConv)
                    } else {
                        val updated = conversation.copy(
                            lastMessage = bodyStr,
                            timestamp = timestamp,
                            unreadCount = conversation.unreadCount + 1
                        )
                        db.conversationDao().updateConversation(updated)
                        conversation.id
                    }

                    // Insert incoming message
                    val msg = Message(
                        conversationId = convId,
                        sender = sender,
                        recipient = "Me",
                        body = bodyStr,
                        timestamp = timestamp,
                        isOutgoing = false,
                        status = MessageStatus.DELIVERED,
                        isRead = false
                    )
                    db.messageDao().insertMessage(msg)
                    Log.d("SmsReceiver", "Received SMS from $sender: $bodyStr")
                }
            }
        }
    }

    private fun getAvatarColorForName(name: String): String {
        val colors = listOf("#EC4899", "#8B5CF6", "#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#14B8A6")
        val index = kotlin.math.abs(name.hashCode()) % colors.size
        return colors[index]
    }
}
