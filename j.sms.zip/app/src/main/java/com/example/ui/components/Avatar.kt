package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.parseAccentColor

@Composable
fun ContactAvatar(
    name: String,
    avatarColorHex: String = "#8B5CF6",
    size: Dp = 48.dp,
    modifier: Modifier = Modifier
) {
    val bgColor = parseAccentColor(avatarColorHex)
    val firstLetter = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: ""
    val isNumberOnly = name.startsWith("+") || name.all { it.isDigit() || it == ' ' || it == '-' }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        if (isNumberOnly || firstLetter.isEmpty()) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = "Contact Avatar",
                tint = Color.White,
                modifier = Modifier.size(size * 0.55f)
            )
        } else {
            Text(
                text = firstLetter,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.42f).sp
            )
        }
    }
}
