package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun JSmsTheme(
    themeMode: String = "AMOLED", // "AMOLED", "LIGHT", "DARK", "SYSTEM"
    accentColorHex: String = "#8B5CF6",
    content: @Composable () -> Unit
) {
    val accentColor = parseAccentColor(accentColorHex)
    val isDark = when (themeMode) {
        "AMOLED", "DARK" -> true
        "LIGHT" -> false
        else -> isSystemInDarkTheme()
    }

    val isAmoled = themeMode == "AMOLED"

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = accentColor,
            onPrimary = Color.White,
            primaryContainer = accentColor.copy(alpha = 0.25f),
            onPrimaryContainer = Color.White,
            background = if (isAmoled) AmoledBlack else AmoledSurfaceDark,
            onBackground = AmoledTextPrimary,
            surface = if (isAmoled) AmoledBlack else AmoledSurfaceDark,
            onSurface = AmoledTextPrimary,
            surfaceVariant = AmoledCardDark,
            onSurfaceVariant = AmoledTextSecondary,
            outline = AmoledCardBorder,
            secondary = accentColor
        )
    } else {
        lightColorScheme(
            primary = accentColor,
            onPrimary = Color.White,
            primaryContainer = accentColor.copy(alpha = 0.15f),
            onPrimaryContainer = accentColor,
            background = LightBackground,
            onBackground = LightTextPrimary,
            surface = LightSurface,
            onSurface = LightTextPrimary,
            surfaceVariant = LightCard,
            onSurfaceVariant = LightTextSecondary,
            outline = Color(0xFFE2E8F0),
            secondary = accentColor
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
