package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SplitViewContainer(
    splitViewEnabled: Boolean,
    splitViewMode: String = "TWO_PANEL",
    hasSelectedConversation: Boolean,
    leftContent: @Composable () -> Unit,
    rightContent: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    val configuration = LocalConfiguration.current
    val screenWidthDp = configuration.screenWidthDp

    // Wide screen or split view explicitly enabled in settings
    val isWideLayout = splitViewEnabled || screenWidthDp >= 600

    // Only splits into strictly two windows when a conversation message is open
    val isSplitActive = isWideLayout && hasSelectedConversation

    var leftWidthRatio by remember { mutableFloatStateOf(0.38f) }

    Row(modifier = modifier.fillMaxSize().testTag("split_view_container")) {
        if (!isSplitActive) {
            // Single view mode: Only 1 view shown when no message is open or on narrow screens
            Box(modifier = Modifier.fillMaxSize()) {
                if (hasSelectedConversation) {
                    rightContent()
                } else {
                    leftContent()
                }
            }
        } else {
            // Strictly TWO WINDOWS side-by-side:
            // Window 1: Left View (Conversations List / Active Screen)
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(leftWidthRatio)
            ) {
                leftContent()
            }

            // Draggable Separator Handle between the two windows
            Box(
                modifier = Modifier
                    .width(12.dp)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { _, dragAmount ->
                            val deltaRatio = dragAmount / (screenWidthDp * 1.8f)
                            leftWidthRatio = (leftWidthRatio + deltaRatio).coerceIn(0.18f, 0.82f)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                    modifier = Modifier
                        .width(4.dp)
                        .height(32.dp)
                ) {}
            }

            // Window 2: Right View (Conversation Thread / Reader)
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f)
            ) {
                rightContent()
            }
        }
    }
}

@Composable
fun EmptyConversationPlaceholder(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("empty_detail_placeholder"),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(24.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.size(80.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Select a conversation to start messaging",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Choose from your list on the left to view messages and reply",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

