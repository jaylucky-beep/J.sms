package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Conversation
import com.example.ui.components.ContactAvatar
import com.example.ui.components.MessageBubble
import com.example.ui.viewmodel.SmsViewModel
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationThreadScreen(
    conversationId: Long,
    viewModel: SmsViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val messages by viewModel.currentConversationMessages.collectAsState()
    val activeConvs by viewModel.activeConversations.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val aiResultText by viewModel.aiResultText.collectAsState()
    val aiLoading by viewModel.aiLoading.collectAsState()

    val currentConv = activeConvs.find { it.id == conversationId }

    var messageText by remember { mutableStateOf("") }
    var showAiSheet by remember { mutableStateOf(false) }
    var showScheduleDialog by remember { mutableStateOf(false) }
    var showDetailsSheet by remember { mutableStateOf(false) }
    var selectedReactionMessageId by remember { mutableStateOf<Long?>(null) }

    // Restore draft if available
    LaunchedEffect(currentConv?.draft) {
        if (!currentConv?.draft.isNullOrEmpty() && messageText.isEmpty()) {
            messageText = currentConv!!.draft
        }
    }

    // Apply AI result text if generated
    LaunchedEffect(aiResultText) {
        aiResultText?.let {
            messageText = it
            viewModel.clearAiResult()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .imePadding(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ContactAvatar(
                            name = currentConv?.contactName ?: currentConv?.address ?: "Message",
                            avatarColorHex = currentConv?.avatarColorHex ?: "#8B5CF6",
                            size = 40.dp
                        )
                        Column {
                            Text(
                                text = currentConv?.contactName?.takeIf { it.isNotEmpty() } ?: currentConv?.address ?: "Conversation",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1
                            )
                            Text(
                                text = currentConv?.address ?: "",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        // Save draft before leaving
                        if (messageText.isNotBlank()) {
                            viewModel.saveDraft(messageText)
                        }
                        onBackClick()
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        // Launch native phone dialer
                        val phone = currentConv?.address ?: ""
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                        context.startActivity(intent)
                    }) {
                        Icon(Icons.Default.Call, contentDescription = "Call")
                    }
                    IconButton(onClick = { showDetailsSheet = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Details")
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 6.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .imePadding()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Attachment / Schedule Button
                        IconButton(
                            onClick = { showScheduleDialog = true },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add attachment or Schedule",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        // AI Helper ✨ Button
                        if (settings.aiAssistantEnabled) {
                            IconButton(
                                onClick = { showAiSheet = true },
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Text("✨", fontSize = 18.sp)
                            }
                        }

                        // Text Field
                        OutlinedTextField(
                            value = messageText,
                            onValueChange = {
                                messageText = it
                                viewModel.saveDraft(it)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("message_input_field"),
                            placeholder = { Text("Type a message...") },
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4
                        )

                        // Send Button
                        IconButton(
                            onClick = {
                                if (messageText.isNotBlank()) {
                                    val recipient = currentConv?.address ?: ""
                                    viewModel.sendMessage(recipient, messageText)
                                    messageText = ""
                                }
                            },
                            enabled = messageText.isNotBlank(),
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (messageText.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                .testTag("send_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = if (messageText.isNotBlank()) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 12.dp),
                reverseLayout = false
            ) {
                items(messages, key = { it.id }) { msg ->
                    MessageBubble(
                        message = msg,
                        onLongClick = { selectedReactionMessageId = msg.id }
                    )
                }
            }
        }
    }

    // Reaction Picker Dialog
    if (selectedReactionMessageId != null) {
        val msgId = selectedReactionMessageId!!
        AlertDialog(
            onDismissRequest = { selectedReactionMessageId = null },
            title = { Text("Add Reaction") },
            text = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("❤️", "👍", "😂", "😮", "😢", "👏").forEach { emoji ->
                        TextButton(onClick = {
                            viewModel.updateMessageReaction(msgId, emoji)
                            selectedReactionMessageId = null
                        }) {
                            Text(emoji, fontSize = 24.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.updateMessageReaction(msgId, null)
                    selectedReactionMessageId = null
                }) {
                    Text("Clear Reaction")
                }
            }
        )
    }

    // Schedule SMS Dialog
    if (showScheduleDialog) {
        AlertDialog(
            onDismissRequest = { showScheduleDialog = false },
            title = { Text("Schedule SMS") },
            text = {
                Column {
                    Text("Schedule this message to be sent automatically at a future time:")
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Time: Tomorrow at 8:00 AM", fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (messageText.isNotBlank()) {
                        val recipient = currentConv?.address ?: ""
                        val name = currentConv?.contactName ?: recipient
                        val scheduledTime = System.currentTimeMillis() + (86400000L) // 24 hours
                        viewModel.scheduleMessage(recipient, name, messageText, scheduledTime)
                        messageText = ""
                        showScheduleDialog = false
                    }
                }) {
                    Text("Schedule for Tomorrow")
                }
            },
            dismissButton = {
                TextButton(onClick = { showScheduleDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // AI Assistant ✨ Bottom Sheet
    if (showAiSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAiSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text("AI Assistant ✨", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))
                Text("Select an action to rewrite or format your message:", style = MaterialTheme.typography.bodyMedium)

                if (aiLoading) {
                    Spacer(modifier = Modifier.height(16.dp))
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
                    Spacer(modifier = Modifier.height(16.dp))
                } else {
                    Spacer(modifier = Modifier.height(16.dp))
                    listOf("Rewrite", "Shorten", "Formal", "Grammar", "Translate").forEach { action ->
                        Button(
                            onClick = {
                                viewModel.processAiAssist(action, messageText)
                                showAiSheet = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(action)
                        }
                    }
                }
            }
        }
    }

    // Details Sheet
    if (showDetailsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showDetailsSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text("Conversation Details", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(12.dp))
                Text("Contact: ${currentConv?.contactName?.takeIf { it.isNotEmpty() } ?: currentConv?.address ?: ""}")
                Text("Address: ${currentConv?.address}")
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        val id = currentConv?.id ?: return@Button
                        val isP = currentConv.isPinned
                        viewModel.togglePin(id, isP)
                        showDetailsSheet = false
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (currentConv?.isPinned == true) "Unpin Conversation" else "Pin Conversation")
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        val id = currentConv?.id ?: return@Button
                        val isM = currentConv.isMuted
                        viewModel.toggleMute(id, isM)
                        showDetailsSheet = false
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (currentConv?.isMuted == true) "Unmute Conversation" else "Mute Conversation")
                }
            }
        }
    }
}
