package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Conversation
import com.example.ui.components.CategoryTabRow
import com.example.ui.components.ConversationCard
import com.example.ui.viewmodel.SmsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationListScreen(
    viewModel: SmsViewModel,
    onOpenConversation: (Long) -> Unit,
    onOpenNewMessage: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPrivateVault: () -> Unit,
    onOpenContacts: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val conversations by viewModel.filteredConversations.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedConvId by viewModel.selectedConversationId.collectAsState()
    val multiSelectedIds by viewModel.multiSelectedIds.collectAsState()
    val totalUnread by viewModel.totalUnreadCount.collectAsState()

    var isSearchActive by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var longPressedConversation by remember { mutableStateOf<Conversation?>(null) }
    var newCategoryName by remember { mutableStateOf("") }

    val isMultiSelectMode = multiSelectedIds.isNotEmpty()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            if (isMultiSelectMode) {
                // Multi-select top app bar
                TopAppBar(
                    title = { Text("${multiSelectedIds.size} selected") },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.clearMultiSelect() }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear selection")
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.selectAllFiltered() }) {
                            Icon(Icons.Default.SelectAll, contentDescription = "Select All")
                        }
                        IconButton(onClick = { viewModel.markMultiSelectedRead(true) }) {
                            Icon(Icons.Default.MarkEmailRead, contentDescription = "Mark Read")
                        }
                        IconButton(onClick = { viewModel.deleteMultiSelected() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
            } else {
                Column {
                    TopAppBar(
                        title = {
                            Text(
                                text = "Messages",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 26.sp
                                )
                            )
                        },
                        actions = {
                            IconButton(onClick = { isSearchActive = !isSearchActive }) {
                                Icon(Icons.Default.Search, contentDescription = "Search")
                            }
                            IconButton(onClick = { onOpenPrivateVault() }) {
                                Icon(Icons.Default.Lock, contentDescription = "Private Vault")
                            }
                            IconButton(onClick = { showMoreMenu = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More options")
                            }

                            DropdownMenu(
                                expanded = showMoreMenu,
                                onDismissRequest = { showMoreMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Select conversations") },
                                    leadingIcon = { Icon(Icons.Default.Checklist, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.selectAllFiltered()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Mark all as read") },
                                    leadingIcon = { Icon(Icons.Default.Drafts, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        viewModel.markMultiSelectedRead(true)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Set as default app") },
                                    leadingIcon = { Icon(Icons.Default.PhonelinkSetup, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        val intent = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                                            val roleManager = context.getSystemService(android.content.Context.ROLE_SERVICE) as? android.app.role.RoleManager
                                            roleManager?.createRequestRoleIntent(android.app.role.RoleManager.ROLE_SMS)
                                        } else {
                                            android.content.Intent(android.provider.Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).apply {
                                                putExtra(android.provider.Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, context.packageName)
                                            }
                                        }
                                        if (intent != null) {
                                            try {
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                android.widget.Toast.makeText(context, "Set J.sms as default in system settings", android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Contacts") },
                                    leadingIcon = { Icon(Icons.Default.Contacts, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onOpenContacts?.invoke()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Private Vault 🔒") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onOpenPrivateVault()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Settings") },
                                    leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                    onClick = {
                                        showMoreMenu = false
                                        onOpenSettings()
                                    }
                                )
                            }
                        }
                    )

                    // Search field animation
                    AnimatedVisibility(visible = isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                                .testTag("search_input"),
                            placeholder = { Text("Search messages, contacts...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(24.dp)
                        )
                    }

                    // Category horizontal tabs
                    CategoryTabRow(
                        categories = categories,
                        selectedCategory = selectedCategory,
                        onCategorySelected = { viewModel.selectCategory(it) },
                        onAddCategoryClick = { showAddCategoryDialog = true }
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenNewMessage,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 16.dp, end = 8.dp)
                    .testTag("compose_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Chat,
                    contentDescription = "New Message",
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Unread Count Banner matching visual reference
                if (totalUnread > 0 && searchQuery.isEmpty()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "$totalUnread unread messages",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "Tap to catch up on latest texts",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = { viewModel.setSearchFilter("Unread") },
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text("View")
                            }
                        }
                    }
                }

                if (conversations.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Inbox,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No messages found",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 88.dp)
                    ) {
                        items(conversations, key = { it.id }) { conv ->
                            ConversationCard(
                                conversation = conv,
                                isSelected = selectedConvId == conv.id,
                                isMultiSelectMode = isMultiSelectMode,
                                isMultiSelected = multiSelectedIds.contains(conv.id),
                                onClick = {
                                    if (isMultiSelectMode) {
                                        viewModel.toggleMultiSelect(conv.id)
                                    } else {
                                        viewModel.selectConversation(conv.id)
                                        onOpenConversation(conv.id)
                                    }
                                },
                                onLongClick = {
                                    if (!isMultiSelectMode) {
                                        longPressedConversation = conv
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Add Category Dialog
    if (showAddCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showAddCategoryDialog = false },
            title = { Text("Add New Category") },
            text = {
                OutlinedTextField(
                    value = newCategoryName,
                    onValueChange = { newCategoryName = it },
                    label = { Text("Category Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newCategoryName.isNotBlank()) {
                            viewModel.addCategory(newCategoryName.trim(), "#3B82F6")
                            newCategoryName = ""
                            showAddCategoryDialog = false
                        }
                    }
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCategoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Long Press Context Dialog / Options Sheet
    longPressedConversation?.let { conv ->
        AlertDialog(
            onDismissRequest = { longPressedConversation = null },
            title = { Text(conv.contactName.takeIf { it.isNotEmpty() } ?: conv.address) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text(if (conv.unreadCount > 0) "Mark as read" else "Mark as unread") },
                        leadingContent = { Icon(Icons.Default.MarkEmailRead, contentDescription = null) },
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                if (conv.unreadCount > 0) viewModel.markAsRead(conv.id) else viewModel.markAsUnread(conv.id)
                                longPressedConversation = null
                            }
                    )
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text(if (conv.isPinned) "Unpin conversation" else "Pin to top") },
                        leadingContent = { Icon(Icons.Default.PushPin, contentDescription = null) },
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                viewModel.togglePin(conv.id, conv.isPinned)
                                longPressedConversation = null
                            }
                    )
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text(if (conv.isMuted) "Unmute notifications" else "Mute conversation") },
                        leadingContent = { Icon(Icons.Default.VolumeOff, contentDescription = null) },
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                viewModel.toggleMute(conv.id, conv.isMuted)
                                longPressedConversation = null
                            }
                    )
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text("Move to Private Vault 🔒") },
                        leadingContent = { Icon(Icons.Default.Lock, contentDescription = null) },
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                viewModel.togglePrivate(conv.id, conv.isPrivate)
                                longPressedConversation = null
                            }
                    )
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text("Delete conversation") },
                        leadingContent = { Icon(Icons.Default.Delete, contentDescription = null) },
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                viewModel.deleteConversation(conv.id)
                                longPressedConversation = null
                            }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { longPressedConversation = null }) {
                    Text("Close")
                }
            }
        )
    }
}
