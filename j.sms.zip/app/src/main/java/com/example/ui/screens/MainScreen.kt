package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.SplitViewContainer
import com.example.ui.theme.JSmsTheme
import com.example.ui.viewmodel.SmsViewModel

@Composable
fun MainScreen(
    viewModel: SmsViewModel
) {
    val settings by viewModel.settings.collectAsState()
    val selectedConvId by viewModel.selectedConversationId.collectAsState()
    val totalUnread by viewModel.totalUnreadCount.collectAsState()
    val configuration = LocalConfiguration.current

    var activeTab by remember { mutableStateOf("conversations") } // "conversations", "contacts", "settings", "new_message", "private_vault"

    val isWideScreen = settings.splitViewEnabled || configuration.screenWidthDp >= 600

    JSmsTheme(
        themeMode = settings.themeMode,
        accentColorHex = settings.accentColorHex
    ) {
        Scaffold(
            bottomBar = {
                if (activeTab != "new_message" && activeTab != "private_vault" && selectedConvId == null) {
                    NavigationBar(
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("bottom_nav_bar")
                    ) {
                        NavigationBarItem(
                            selected = activeTab == "conversations",
                            onClick = { activeTab = "conversations" },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (totalUnread > 0) {
                                            Badge { Text(if (totalUnread > 99) "99+" else totalUnread.toString()) }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.ChatBubble, contentDescription = "Conversations")
                                }
                            },
                            label = { Text("Conversations", fontWeight = FontWeight.SemiBold) },
                            modifier = Modifier.testTag("nav_item_conversations")
                        )

                        NavigationBarItem(
                            selected = activeTab == "contacts",
                            onClick = { activeTab = "contacts" },
                            icon = { Icon(Icons.Default.Contacts, contentDescription = "Contacts") },
                            label = { Text("Contacts", fontWeight = FontWeight.SemiBold) },
                            modifier = Modifier.testTag("nav_item_contacts")
                        )

                        NavigationBarItem(
                            selected = activeTab == "settings",
                            onClick = { activeTab = "settings" },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                            label = { Text("Settings", fontWeight = FontWeight.SemiBold) },
                            modifier = Modifier.testTag("nav_item_settings")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                SplitViewContainer(
                    splitViewEnabled = settings.splitViewEnabled,
                    splitViewMode = settings.splitViewMode,
                    hasSelectedConversation = selectedConvId != null,
                    leftContent = {
                        when (activeTab) {
                            "new_message" -> {
                                NewMessageScreen(
                                    viewModel = viewModel,
                                    onBackClick = { activeTab = "conversations" }
                                )
                            }

                            "private_vault" -> {
                                PrivateVaultScreen(
                                    viewModel = viewModel,
                                    onBackClick = { activeTab = "conversations" },
                                    onOpenConversation = { id ->
                                        viewModel.selectConversation(id)
                                        activeTab = "conversations"
                                    }
                                )
                            }

                            "contacts" -> {
                                ContactsScreen(
                                    viewModel = viewModel,
                                    onStartChat = { phone, name ->
                                        viewModel.createAndOpenConversation(phone, "Hello!", name)
                                        activeTab = "conversations"
                                    }
                                )
                            }

                            "settings" -> {
                                SettingsScreen(
                                    viewModel = viewModel,
                                    onBackClick = { activeTab = "conversations" }
                                )
                            }

                            else -> { // "conversations"
                                ConversationListScreen(
                                    viewModel = viewModel,
                                    onOpenConversation = { id ->
                                        viewModel.selectConversation(id)
                                    },
                                    onOpenNewMessage = { activeTab = "new_message" },
                                    onOpenSettings = { activeTab = "settings" },
                                    onOpenPrivateVault = { activeTab = "private_vault" },
                                    onOpenContacts = { activeTab = "contacts" }
                                )
                            }
                        }
                    },
                    rightContent = {
                        if (selectedConvId != null) {
                            ConversationThreadScreen(
                                conversationId = selectedConvId!!,
                                viewModel = viewModel,
                                onBackClick = { viewModel.selectConversation(null) }
                            )
                        }
                    }
                )
            }
        }
    }
}

