package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*
import com.example.ui.viewmodel.SmsViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SmsViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val settings by viewModel.settings.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedJsonText by remember { mutableStateOf("") }
    var importJsonInput by remember { mutableStateOf("") }
    var showImportDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 40.dp)
        ) {
            // Settings Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search settings...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .testTag("settings_search_input"),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true
                )
            }

            // 1. APPEARANCE
            if (searchQuery.isBlank() || "appearance theme color dark light amoled".contains(searchQuery, ignoreCase = true)) {
                item {
                    SettingsCategoryHeader("Appearance & Themes")
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Theme Preset", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                listOf("AMOLED", "DARK", "LIGHT", "SYSTEM").forEach { mode ->
                                    FilterChip(
                                        selected = settings.themeMode == mode,
                                        onClick = {
                                            viewModel.updateSettings(settings.copy(themeMode = mode))
                                        },
                                        label = { Text(mode) }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Accent Color", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                val colors = listOf(
                                    "#8B5CF6" to "Purple",
                                    "#3B82F6" to "Blue",
                                    "#14B8A6" to "Teal",
                                    "#EC4899" to "Pink",
                                    "#F97316" to "Orange",
                                    "#10B981" to "Green",
                                    "#EF4444" to "Red"
                                )
                                colors.forEach { (hex, name) ->
                                    val isSel = settings.accentColorHex.equals(hex, ignoreCase = true)
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(parseAccentColor(hex))
                                            .clickable {
                                                viewModel.updateSettings(settings.copy(accentColorHex = hex))
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSel) {
                                            Icon(Icons.Default.Check, contentDescription = name, tint = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. SPLIT VIEW
            if (searchQuery.isBlank() || "split view layout multi pane tablet".contains(searchQuery, ignoreCase = true)) {
                item {
                    SettingsCategoryHeader("Split View Layout")
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Split View", fontWeight = FontWeight.Bold)
                                    Text("Enable two-pane layout on wider screens", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = settings.splitViewEnabled,
                                    onCheckedChange = {
                                        viewModel.updateSettings(settings.copy(splitViewEnabled = it))
                                    },
                                    modifier = Modifier.testTag("split_view_switch")
                                )
                            }

                            AnimatedVisibility(visible = settings.splitViewEnabled) {
                                Column(modifier = Modifier.padding(top = 12.dp)) {
                                    Text("Split Layout", fontWeight = FontWeight.SemiBold)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("TWO_PANEL", "AUTO").forEach { mode ->
                                            FilterChip(
                                                selected = settings.splitViewMode == mode,
                                                onClick = {
                                                    viewModel.updateSettings(settings.copy(splitViewMode = mode))
                                                },
                                                label = { Text(if (mode == "TWO_PANEL") "Two Windows" else "Auto (Adaptive)") }
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Only two windows: conversation list on left and reader on right.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. MESSAGING & COMPOSER
            if (searchQuery.isBlank() || "messaging enter send draft sms".contains(searchQuery, ignoreCase = true)) {
                item {
                    SettingsCategoryHeader("Messaging Behavior")
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Send on Enter", fontWeight = FontWeight.Bold)
                                    Text("Press Enter on keyboard to send message", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = settings.sendOnEnter,
                                    onCheckedChange = {
                                        viewModel.updateSettings(settings.copy(sendOnEnter = it))
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // 4. DEFAULT APP & SYSTEM
            if (searchQuery.isBlank() || "default app system sms role messaging".contains(searchQuery, ignoreCase = true)) {
                item {
                    SettingsCategoryHeader("Default Application")
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Set J.sms as Default SMS App", fontWeight = FontWeight.Bold)
                                    Text("Handle all incoming and outgoing messages with J.sms", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Button(
                                    onClick = {
                                        val intent = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                                            val roleManager = context.getSystemService(android.content.Context.ROLE_SERVICE) as? android.app.role.RoleManager
                                            roleManager?.createRequestRoleIntent(android.app.role.RoleManager.ROLE_SMS)
                                        } else {
                                            android.content.Intent(android.provider.Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).apply {
                                                putExtra(android.provider.Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, context.packageName)
                                            }
                                        }
                                        if (intent != null) {
                                            try {
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Set J.sms as default in system settings", Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            Toast.makeText(context, "J.sms is set as default app", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.testTag("set_default_app_button")
                                ) {
                                    Text("Set Default")
                                }
                            }
                        }
                    }
                }
            }

            // 5. PRIVACY & SECURITY
            if (searchQuery.isBlank() || "privacy security lock passcode vault".contains(searchQuery, ignoreCase = true)) {
                item {
                    SettingsCategoryHeader("Privacy & Vault Lock")
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Private Vault Protection", fontWeight = FontWeight.Bold)
                                    Text("Private conversations are secured with PIN security", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // 5. BACKUP & RESTORE
            if (searchQuery.isBlank() || "backup restore export import local".contains(searchQuery, ignoreCase = true)) {
                item {
                    SettingsCategoryHeader("Local Offline Backup")
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Local Storage Backup & Export", fontWeight = FontWeight.Bold)
                            Text("All backups stay 100% offline on your device.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            exportedJsonText = viewModel.repository.exportDataJson()
                                            showExportDialog = true
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Upload, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Export JSON")
                                }

                                OutlinedButton(
                                    onClick = { showImportDialog = true },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Import")
                                }
                            }
                        }
                    }
                }
            }

            // 6. ABOUT
            if (searchQuery.isBlank() || "about version info".contains(searchQuery, ignoreCase = true)) {
                item {
                    SettingsCategoryHeader("About J.sms")
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("J.sms Messenger v1.0", fontWeight = FontWeight.Bold)
                            Text("Offline-first Android SMS & MMS Application", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Designed for speed, privacy, and full offline autonomy.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    // Export Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Exported Local Data") },
            text = {
                OutlinedTextField(
                    value = exportedJsonText,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth().height(200.dp)
                )
            },
            confirmButton = {
                Button(onClick = { showExportDialog = false }) {
                    Text("Copy & Close")
                }
            }
        )
    }

    // Import Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("Import Backup JSON") },
            text = {
                OutlinedTextField(
                    value = importJsonInput,
                    onValueChange = { importJsonInput = it },
                    placeholder = { Text("Paste JSON backup data here...") },
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )
            },
            confirmButton = {
                Button(onClick = {
                    coroutineScope.launch {
                        val success = viewModel.repository.importDataJson(importJsonInput)
                        if (success) {
                            Toast.makeText(context, "Data imported successfully!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Invalid JSON format!", Toast.LENGTH_SHORT).show()
                        }
                        showImportDialog = false
                    }
                }) {
                    Text("Import")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SettingsCategoryHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 16.dp, bottom = 6.dp)
    )
}
