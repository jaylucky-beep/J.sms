package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Amoled Black Palette
val AmoledBlack = Color(0xFF000000)
val AmoledSurfaceDark = Color(0xFF0C0F17)
val AmoledCardDark = Color(0xFF151A26)
val AmoledCardBorder = Color(0xFF222938)
val AmoledTextPrimary = Color(0xFFF1F5F9)
val AmoledTextSecondary = Color(0xFF94A3B8)

// Light Mode Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF1F5F9)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Accent Color Options
val AccentPurple = Color(0xFF8B5CF6)
val AccentBlue = Color(0xFF3B82F6)
val AccentTeal = Color(0xFF14B8A6)
val AccentPink = Color(0xFFEC4899)
val AccentOrange = Color(0xFFF97316)
val AccentGreen = Color(0xFF10B981)
val AccentRed = Color(0xFFEF4444)

fun parseAccentColor(hexStr: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hexStr))
    } catch (e: Exception) {
        AccentPurple
    }
}
