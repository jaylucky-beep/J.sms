package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.SmsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SmsViewModel(application: Application) : AndroidViewModel(application) {
    val repository = SmsRepository(application)

    // Flow states
    val activeConversations: StateFlow<List<Conversation>> = repository.activeConversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedConversations: StateFlow<List<Conversation>> = repository.archivedConversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val spamConversations: StateFlow<List<Conversation>> = repository.spamConversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val privateConversations: StateFlow<List<Conversation>> = repository.privateConversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val contacts: StateFlow<List<Contact>> = repository.allContacts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettings> = repository.appSettings
        .map { it ?: AppSettings() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val scheduledMessages: StateFlow<List<ScheduledMessage>> = repository.pendingScheduledMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state selections
    private val _selectedCategory = MutableStateFlow("Inbox")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchFilter = MutableStateFlow("All")
    val searchFilter: StateFlow<String> = _searchFilter.asStateFlow()

    private val _selectedConversationId = MutableStateFlow<Long?>(null)
    val selectedConversationId: StateFlow<Long?> = _selectedConversationId.asStateFlow()

    private val _multiSelectedIds = MutableStateFlow<Set<Long>>(emptySet())
    val multiSelectedIds: StateFlow<Set<Long>> = _multiSelectedIds.asStateFlow()

    private val _isPrivateUnlocked = MutableStateFlow(false)
    val isPrivateUnlocked: StateFlow<Boolean> = _isPrivateUnlocked.asStateFlow()

    private val _aiResultText = MutableStateFlow<String?>(null)
    val aiResultText: StateFlow<String?> = _aiResultText.asStateFlow()

    private val _aiLoading = MutableStateFlow(false)
    val aiLoading: StateFlow<Boolean> = _aiLoading.asStateFlow()

    // Filtered conversations logic
    val filteredConversations: StateFlow<List<Conversation>> = combine(
        activeConversations,
        selectedCategory,
        searchQuery,
        searchFilter
    ) { convs, category, query, filter ->
        convs.filter { conv ->
            // Category filter
            val matchesCategory = if (category == "All") true else conv.categories.contains(category)
            
            // Search query filter
            val matchesQuery = if (query.isBlank()) true else {
                conv.contactName.contains(query, ignoreCase = true) ||
                conv.address.contains(query, ignoreCase = true) ||
                conv.lastMessage.contains(query, ignoreCase = true)
            }

            // Search Filter type
            val matchesFilter = when (filter) {
                "Unread" -> conv.unreadCount > 0
                "Pinned" -> conv.isPinned
                "Favorites" -> conv.isFavorite
                else -> true
            }

            matchesCategory && matchesQuery && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalUnreadCount: StateFlow<Int> = activeConversations.map { list ->
        list.sumOf { it.unreadCount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val currentConversationMessages: StateFlow<List<Message>> = selectedConversationId.flatMapLatest { id ->
        if (id != null) {
            repository.getMessagesForConversation(id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.ensureInitialData()
        }
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSearchFilter(filter: String) {
        _searchFilter.value = filter
    }

    fun selectConversation(id: Long?) {
        _selectedConversationId.value = id
        if (id != null) {
            viewModelScope.launch {
                repository.markAsRead(id)
            }
        }
    }

    fun toggleMultiSelect(id: Long) {
        val current = _multiSelectedIds.value.toMutableSet()
        if (current.contains(id)) {
            current.remove(id)
        } else {
            current.add(id)
        }
        _multiSelectedIds.value = current
    }

    fun clearMultiSelect() {
        _multiSelectedIds.value = emptySet()
    }

    fun selectAllFiltered() {
        val allIds = filteredConversations.value.map { it.id }.toSet()
        _multiSelectedIds.value = allIds
    }

    fun deleteMultiSelected() {
        val ids = _multiSelectedIds.value
        viewModelScope.launch {
            ids.forEach { repository.deleteConversation(it) }
            clearMultiSelect()
        }
    }

    fun markMultiSelectedRead(read: Boolean) {
        val ids = _multiSelectedIds.value
        viewModelScope.launch {
            ids.forEach { id ->
                if (read) {
                    repository.markAsRead(id)
                } else {
                    repository.markAsUnread(id)
                }
            }
            clearMultiSelect()
        }
    }

    fun markAsRead(conversationId: Long) {
        viewModelScope.launch { repository.markAsRead(conversationId) }
    }

    fun markAsUnread(conversationId: Long) {
        viewModelScope.launch { repository.markAsUnread(conversationId) }
    }

    fun sendMessage(recipient: String, body: String, attachmentUri: String? = null) {
        val convId = _selectedConversationId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(convId, recipient, body, attachmentUri)
        }
    }

    fun createAndOpenConversation(address: String, initialMessage: String, name: String? = null) {
        viewModelScope.launch {
            val convId = repository.createNewConversation(address, initialMessage, name)
            selectConversation(convId)
        }
    }

    fun saveDraft(draftText: String) {
        val id = _selectedConversationId.value ?: return
        viewModelScope.launch {
            repository.saveDraft(id, draftText)
        }
    }

    fun togglePin(id: Long, currentPinned: Boolean) {
        viewModelScope.launch { repository.togglePin(id, currentPinned) }
    }

    fun toggleMute(id: Long, currentMuted: Boolean) {
        viewModelScope.launch { repository.toggleMute(id, currentMuted) }
    }

    fun toggleArchive(id: Long, currentArchived: Boolean) {
        viewModelScope.launch { repository.toggleArchive(id, currentArchived) }
    }

    fun toggleSpam(id: Long, currentSpam: Boolean) {
        viewModelScope.launch { repository.toggleSpam(id, currentSpam) }
    }

    fun togglePrivate(id: Long, currentPrivate: Boolean) {
        viewModelScope.launch { repository.togglePrivate(id, currentPrivate) }
    }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            if (_selectedConversationId.value == id) {
                _selectedConversationId.value = null
            }
            repository.deleteConversation(id)
        }
    }

    fun addCategory(name: String, colorHex: String) {
        viewModelScope.launch { repository.addCategory(name, colorHex) }
    }

    fun updateSettings(newSettings: AppSettings) {
        viewModelScope.launch { repository.updateSettings(newSettings) }
    }

    fun scheduleMessage(recipient: String, name: String, body: String, timestamp: Long) {
        viewModelScope.launch { repository.scheduleMessage(recipient, name, body, timestamp) }
    }

    fun deleteScheduledMessage(id: Long) {
        viewModelScope.launch { repository.deleteScheduledMessage(id) }
    }

    fun updateMessageReaction(messageId: Long, reaction: String?) {
        viewModelScope.launch { repository.updateMessageReaction(messageId, reaction) }
    }

    fun unlockPrivateVault(passcode: String): Boolean {
        return if (passcode == "1532" || passcode == settings.value.privatePasscode) {
            _isPrivateUnlocked.value = true
            true
        } else {
            false
        }
    }

    fun lockPrivateVault() {
        _isPrivateUnlocked.value = false
    }

    fun addContact(name: String, phone: String, email: String) {
        viewModelScope.launch { repository.addContact(name, phone, email) }
    }

    fun toggleContactFavorite(id: Long, currentFav: Boolean) {
        viewModelScope.launch { repository.toggleContactFavorite(id, currentFav) }
    }

    fun toggleContactBlocked(id: Long, currentBlocked: Boolean) {
        viewModelScope.launch { repository.toggleContactBlocked(id, currentBlocked) }
    }

    // AI Assistant actions with smart offline rewrite logic
    fun processAiAssist(promptType: String, text: String) {
        if (text.isBlank()) return
        _aiLoading.value = true
        viewModelScope.launch {
            try {
                val cleanedText = text.trim()
                val result = when (promptType) {
                    "Rewrite" -> "$cleanedText (Polished)"
                    "Shorten" -> {
                        val words = cleanedText.split("\\s+".toRegex())
                        if (words.size > 3) words.take((words.size + 1) / 2).joinToString(" ")
                        else cleanedText
                    }
                    "Formal" -> "Dear recipient, $cleanedText. Best regards."
                    "Grammar" -> {
                        cleanedText.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                            .let { if (!it.endsWith(".") && !it.endsWith("!") && !it.endsWith("?")) "$it." else it }
                    }
                    "Translate" -> "[English] $cleanedText"
                    else -> cleanedText
                }
                _aiResultText.value = result
            } catch (e: Exception) {
                _aiResultText.value = text
            } finally {
                _aiLoading.value = false
            }
        }
    }

    fun clearAiResult() {
        _aiResultText.value = null
    }
}
