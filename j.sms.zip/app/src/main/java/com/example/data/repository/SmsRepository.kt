package com.example.data.repository

import android.content.Context
import android.telephony.SmsManager
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class SmsRepository(private val context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()
    private val contactDao = db.contactDao()
    private val categoryDao = db.categoryDao()
    private val scheduledMessageDao = db.scheduledMessageDao()
    private val settingsDao = db.settingsDao()

    val activeConversations: Flow<List<Conversation>> = conversationDao.getAllActiveConversations()
    val archivedConversations: Flow<List<Conversation>> = conversationDao.getArchivedConversations()
    val spamConversations: Flow<List<Conversation>> = conversationDao.getSpamConversations()
    val privateConversations: Flow<List<Conversation>> = conversationDao.getPrivateConversations()
    val allCategories: Flow<List<Category>> = categoryDao.getAllCategories()
    val allContacts: Flow<List<Contact>> = contactDao.getAllContacts()
    val favoriteContacts: Flow<List<Contact>> = contactDao.getFavoriteContacts()
    val blockedContacts: Flow<List<Contact>> = contactDao.getBlockedContacts()
    val pendingScheduledMessages: Flow<List<ScheduledMessage>> = scheduledMessageDao.getPendingScheduledMessages()
    val appSettings: Flow<AppSettings?> = settingsDao.getSettingsFlow()

    suspend fun ensureInitialData() = withContext(Dispatchers.IO) {
        // Ensure default settings exist
        if (settingsDao.getSettingsOnce() == null) {
            settingsDao.saveSettings(AppSettings())
        }

        // Ensure categories exist
        val existingCategories = categoryDao.getAllCategories().firstOrNull()
        if (existingCategories.isNullOrEmpty()) {
            val defaults = listOf(
                Category(name = "Inbox", colorHex = "#8B5CF6", iconName = "Inbox", isDefault = true),
                Category(name = "Work messages", colorHex = "#3B82F6", iconName = "Work"),
                Category(name = "Bills", colorHex = "#EF4444", iconName = "Receipt")
            )
            defaults.forEach { categoryDao.insertCategory(it) }
        }

        // Ensure default initial contacts exist
        val existingContacts = contactDao.getAllContacts().firstOrNull()
        if (existingContacts.isNullOrEmpty()) {
            val sampleContacts = listOf(
                Contact(name = "Zain Bob", phoneNumber = "+27821234567", avatarColorHex = "#EC4899", isFavorite = true),
                Contact(name = "Yanick", phoneNumber = "082 596 4818", avatarColorHex = "#3B82F6"),
                Contact(name = "Google", phoneNumber = "22000", avatarColorHex = "#EA4335"),
                Contact(name = "Nedbank", phoneNumber = "+2781160754784865", avatarColorHex = "#10B981")
            )
            sampleContacts.forEach { contactDao.insertContact(it) }
        }

        // Ensure default initial conversations exist (matching visual reference photos)
        val existingConvs = conversationDao.getAllActiveConversations().firstOrNull()
        if (existingConvs.isNullOrEmpty()) {
            seedReferenceConversations()
        }
    }

    private suspend fun seedReferenceConversations() {
        val now = System.currentTimeMillis()
        val dayMillis = 86400000L

        // 1. Zain Bob
        val zainConvId = conversationDao.insertConversation(
            Conversation(
                address = "Zain Bob",
                contactName = "Zain Bob",
                lastMessage = "I'll call you back..",
                timestamp = now - (dayMillis * 30),
                unreadCount = 0,
                isPinned = true,
                categories = "Inbox,Work messages",
                avatarColorHex = "#EC4899"
            )
        )
        messageDao.insertMessage(Message(conversationId = zainConvId, sender = "Zain Bob", recipient = "Me", body = "Hey, are you free for the meeting?", timestamp = now - (dayMillis * 30) - 3600000, isOutgoing = false))
        messageDao.insertMessage(Message(conversationId = zainConvId, sender = "Me", recipient = "Zain Bob", body = "Can't talk right now.", timestamp = now - (dayMillis * 30) - 1800000, isOutgoing = true))
        messageDao.insertMessage(Message(conversationId = zainConvId, sender = "Zain Bob", recipient = "Me", body = "I'll call you back..", timestamp = now - (dayMillis * 30), isOutgoing = false))

        // 2. Yanick
        val yanickConvId = conversationDao.insertConversation(
            Conversation(
                address = "Yanick",
                contactName = "Yanick",
                lastMessage = "[Name] gilbert driver [Mobile] 082 596 4818",
                timestamp = now - (dayMillis * 90),
                unreadCount = 0,
                isPinned = true,
                categories = "Inbox,Work messages",
                avatarColorHex = "#3B82F6"
            )
        )
        messageDao.insertMessage(Message(conversationId = yanickConvId, sender = "Yanick", recipient = "Me", body = "Here is the driver info:", timestamp = now - (dayMillis * 90) - 600000, isOutgoing = false))
        messageDao.insertMessage(Message(conversationId = yanickConvId, sender = "Yanick", recipient = "Me", body = "[Name] gilbert driver [Mobile] 082 596 4818", timestamp = now - (dayMillis * 90), isOutgoing = false))

        // 3. Safari Outdoor
        val safariConvId = conversationDao.insertConversation(
            Conversation(
                address = "+2781160004099759",
                contactName = "+2781160004099759",
                lastMessage = "Safari Outdoor LAST OF THE BEST SELLERS SALE, 4 days only! Don't miss out on amazing deals...",
                timestamp = now - 3600000 * 3,
                unreadCount = 1,
                categories = "Inbox",
                avatarColorHex = "#F59E0B"
            )
        )
        messageDao.insertMessage(Message(conversationId = safariConvId, sender = "+2781160004099759", recipient = "Me", body = "Safari Outdoor LAST OF THE BEST SELLERS SALE, 4 days only! Don't miss out on amazing deals on outdoor equipment.", timestamp = now - 3600000 * 3, isOutgoing = false, isRead = false))

        // 4. Nedbank
        val nedbankConvId = conversationDao.insertConversation(
            Conversation(
                address = "+2781160754784865",
                contactName = "+2781160754784865",
                lastMessage = "Nedbank: Transaction. Purchase of R300,00 on a/c **1208 at ENGEN BATES SERV STATI Po. 26 Oct 24 at...",
                timestamp = now - dayMillis,
                unreadCount = 13,
                categories = "Inbox,Bills",
                avatarColorHex = "#10B981"
            )
        )
        messageDao.insertMessage(Message(conversationId = nedbankConvId, sender = "+2781160754784865", recipient = "Me", body = "Nedbank: Transaction. Purchase of R300,00 on a/c **1208 at ENGEN BATES SERV STATI Po. 26 Oct 24 at 14:12.", timestamp = now - dayMillis, isOutgoing = false, isRead = false))

        // 5. Google
        val googleConvId = conversationDao.insertConversation(
            Conversation(
                address = "Google",
                contactName = "Google",
                lastMessage = "G-021343 is your Google verification code. Don't share your code with anyone.",
                timestamp = now - dayMillis * 2,
                unreadCount = 1,
                categories = "Inbox",
                avatarColorHex = "#EA4335"
            )
        )
        messageDao.insertMessage(Message(conversationId = googleConvId, sender = "Google", recipient = "Me", body = "G-021343 is your Google verification code. Don't share your code with anyone.", timestamp = now - dayMillis * 2, isOutgoing = false, isRead = false))
    }

    fun getMessagesForConversation(conversationId: Long): Flow<List<Message>> {
        return messageDao.getMessagesForConversation(conversationId)
    }

    suspend fun getConversationById(id: Long): Conversation? {
        return conversationDao.getConversationById(id)
    }

    suspend fun sendMessage(conversationId: Long, recipient: String, body: String, attachmentUri: String? = null): Long = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()

        // Insert message
        val msg = Message(
            conversationId = conversationId,
            sender = "Me",
            recipient = recipient,
            body = body,
            timestamp = timestamp,
            isOutgoing = true,
            status = MessageStatus.SENT,
            isRead = true,
            attachmentUri = attachmentUri
        )
        val msgId = messageDao.insertMessage(msg)

        // Try sending native SMS if system allows
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(recipient, null, body, null, null)
            Log.d("SmsRepository", "Native SMS sent to $recipient")
        } catch (e: Exception) {
            Log.d("SmsRepository", "Native SMS send bypassed / local offline mode: ${e.message}")
        }

        // Update conversation state
        val conv = conversationDao.getConversationById(conversationId)
        if (conv != null) {
            val updated = conv.copy(
                lastMessage = body,
                timestamp = timestamp,
                draft = ""
            )
            conversationDao.updateConversation(updated)
        }

        msgId
    }

    suspend fun createNewConversation(address: String, initialMessage: String, contactName: String? = null): Long = withContext(Dispatchers.IO) {
        var conv = conversationDao.getConversationByAddress(address)
        val convId = if (conv == null) {
            val name = contactName ?: address
            val newConv = Conversation(
                address = address,
                contactName = name,
                lastMessage = initialMessage,
                timestamp = System.currentTimeMillis(),
                unreadCount = 0,
                categories = "Inbox",
                avatarColorHex = getAvatarColorForName(name)
            )
            conversationDao.insertConversation(newConv)
        } else {
            conv.id
        }

        sendMessage(convId, address, initialMessage)
        convId
    }

    suspend fun saveDraft(conversationId: Long, draftText: String) = withContext(Dispatchers.IO) {
        conversationDao.updateDraft(conversationId, draftText)
    }

    suspend fun markAsRead(conversationId: Long) = withContext(Dispatchers.IO) {
        conversationDao.markAsRead(conversationId)
    }

    suspend fun markAsUnread(conversationId: Long) = withContext(Dispatchers.IO) {
        val conv = conversationDao.getConversationById(conversationId)
        if (conv != null) {
            conversationDao.updateConversation(conv.copy(unreadCount = 1))
        }
    }

    suspend fun togglePin(conversationId: Long, currentPinned: Boolean) = withContext(Dispatchers.IO) {
        conversationDao.setPinned(conversationId, !currentPinned)
    }

    suspend fun toggleMute(conversationId: Long, currentMuted: Boolean) = withContext(Dispatchers.IO) {
        conversationDao.setMuted(conversationId, !currentMuted)
    }

    suspend fun toggleArchive(conversationId: Long, currentArchived: Boolean) = withContext(Dispatchers.IO) {
        conversationDao.setArchived(conversationId, !currentArchived)
    }

    suspend fun toggleSpam(conversationId: Long, currentSpam: Boolean) = withContext(Dispatchers.IO) {
        conversationDao.setSpam(conversationId, !currentSpam)
    }

    suspend fun togglePrivate(conversationId: Long, currentPrivate: Boolean) = withContext(Dispatchers.IO) {
        conversationDao.setPrivate(conversationId, !currentPrivate)
    }

    suspend fun deleteConversation(conversationId: Long) = withContext(Dispatchers.IO) {
        messageDao.deleteMessagesForConversation(conversationId)
        conversationDao.deleteConversationById(conversationId)
    }

    suspend fun updateCategoriesForConversation(conversationId: Long, categoriesStr: String) = withContext(Dispatchers.IO) {
        conversationDao.updateCategories(conversationId, categoriesStr)
    }

    suspend fun addCategory(name: String, colorHex: String) = withContext(Dispatchers.IO) {
        categoryDao.insertCategory(Category(name = name, colorHex = colorHex))
    }

    suspend fun deleteCategory(id: Long) = withContext(Dispatchers.IO) {
        categoryDao.deleteCategoryById(id)
    }

    suspend fun updateSettings(settings: AppSettings) = withContext(Dispatchers.IO) {
        settingsDao.saveSettings(settings)
    }

    suspend fun scheduleMessage(recipient: String, contactName: String, body: String, scheduledTimeMillis: Long) = withContext(Dispatchers.IO) {
        val item = ScheduledMessage(
            recipient = recipient,
            contactName = contactName,
            body = body,
            scheduledTimestamp = scheduledTimeMillis
        )
        scheduledMessageDao.insertScheduledMessage(item)
    }

    suspend fun deleteScheduledMessage(id: Long) = withContext(Dispatchers.IO) {
        scheduledMessageDao.deleteScheduledMessage(id)
    }

    suspend fun updateMessageReaction(messageId: Long, reaction: String?) = withContext(Dispatchers.IO) {
        messageDao.updateMessageReaction(messageId, reaction)
    }

    suspend fun exportDataJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        val allMessages = messageDao.getAllMessagesOnce()
        val messagesArray = JSONArray()
        for (m in allMessages) {
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("sender", m.sender)
            obj.put("recipient", m.recipient)
            obj.put("body", m.body)
            obj.put("timestamp", m.timestamp)
            messagesArray.put(obj)
        }
        root.put("messages", messagesArray)
        root.put("exportedAt", System.currentTimeMillis())
        root.toString(2)
    }

    suspend fun importDataJson(jsonStr: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonStr)
            val array = root.getJSONArray("messages")
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val sender = item.getString("sender")
                val body = item.getString("body")
                val timestamp = item.getLong("timestamp")
                
                var conv = conversationDao.getConversationByAddress(sender)
                val convId = if (conv == null) {
                    val newConv = Conversation(
                        address = sender,
                        contactName = sender,
                        lastMessage = body,
                        timestamp = timestamp,
                        avatarColorHex = getAvatarColorForName(sender)
                    )
                    conversationDao.insertConversation(newConv)
                } else {
                    conv.id
                }

                messageDao.insertMessage(
                    Message(
                        conversationId = convId,
                        sender = sender,
                        recipient = "Me",
                        body = body,
                        timestamp = timestamp,
                        isOutgoing = sender == "Me",
                        status = MessageStatus.SENT,
                        isRead = true
                    )
                )
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun addContact(name: String, phone: String, email: String) = withContext(Dispatchers.IO) {
        contactDao.insertContact(
            Contact(
                name = name,
                phoneNumber = phone,
                email = email,
                avatarColorHex = getAvatarColorForName(name)
            )
        )
    }

    suspend fun toggleContactFavorite(id: Long, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        contactDao.setFavorite(id, !isFavorite)
    }

    suspend fun toggleContactBlocked(id: Long, isBlocked: Boolean) = withContext(Dispatchers.IO) {
        contactDao.setBlocked(id, !isBlocked)
    }

    private fun getAvatarColorForName(name: String): String {
        val colors = listOf("#EC4899", "#8B5CF6", "#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#14B8A6")
        val index = kotlin.math.abs(name.hashCode()) % colors.size
        return colors[index]
    }
}
