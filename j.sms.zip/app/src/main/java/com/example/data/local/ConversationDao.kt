package com.example.data.local

import androidx.room.*
import com.example.data.model.Conversation
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations WHERE isArchived = 0 AND isSpam = 0 AND isPrivate = 0 ORDER BY isPinned DESC, timestamp DESC")
    fun getAllActiveConversations(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE isArchived = 1 ORDER BY timestamp DESC")
    fun getArchivedConversations(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE isSpam = 1 ORDER BY timestamp DESC")
    fun getSpamConversations(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE isPrivate = 1 ORDER BY timestamp DESC")
    fun getPrivateConversations(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun getConversationById(id: Long): Conversation?

    @Query("SELECT * FROM conversations WHERE address = :address LIMIT 1")
    suspend fun getConversationByAddress(address: String): Conversation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: Conversation): Long

    @Update
    suspend fun updateConversation(conversation: Conversation)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversationById(id: Long)

    @Query("UPDATE conversations SET draft = :draft WHERE id = :id")
    suspend fun updateDraft(id: Long, draft: String)

    @Query("UPDATE conversations SET unreadCount = 0 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE conversations SET unreadCount = :count WHERE id = :id")
    suspend fun setUnreadCount(id: Long, count: Int)

    @Query("UPDATE conversations SET isPinned = :isPinned WHERE id = :id")
    suspend fun setPinned(id: Long, isPinned: Boolean)

    @Query("UPDATE conversations SET isMuted = :isMuted WHERE id = :id")
    suspend fun setMuted(id: Long, isMuted: Boolean)

    @Query("UPDATE conversations SET isArchived = :isArchived WHERE id = :id")
    suspend fun setArchived(id: Long, isArchived: Boolean)

    @Query("UPDATE conversations SET isSpam = :isSpam WHERE id = :id")
    suspend fun setSpam(id: Long, isSpam: Boolean)

    @Query("UPDATE conversations SET isPrivate = :isPrivate WHERE id = :id")
    suspend fun setPrivate(id: Long, isPrivate: Boolean)

    @Query("UPDATE conversations SET categories = :categories WHERE id = :id")
    suspend fun updateCategories(id: Long, categories: String)

    @Query("DELETE FROM conversations")
    suspend fun deleteAllConversations()
}
