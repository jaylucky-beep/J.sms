package com.example.data.local

import androidx.room.*
import com.example.data.model.ScheduledMessage
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduledMessageDao {
    @Query("SELECT * FROM scheduled_messages WHERE isSent = 0 ORDER BY scheduledTimestamp ASC")
    fun getPendingScheduledMessages(): Flow<List<ScheduledMessage>>

    @Query("SELECT * FROM scheduled_messages ORDER BY scheduledTimestamp DESC")
    fun getAllScheduledMessages(): Flow<List<ScheduledMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScheduledMessage(scheduledMessage: ScheduledMessage): Long

    @Update
    suspend fun updateScheduledMessage(scheduledMessage: ScheduledMessage)

    @Query("DELETE FROM scheduled_messages WHERE id = :id")
    suspend fun deleteScheduledMessage(id: Long)
}
