package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey
    val key: String = "default_config",
    val themeMode: String = "AMOLED", // "AMOLED", "LIGHT", "DARK", "SYSTEM"
    val accentColorHex: String = "#8B5CF6", // Purple/Blue preset
    val splitViewEnabled: Boolean = true,
    val splitViewMode: String = "TWO_PANEL", // "TWO_PANEL", "AUTO"
    val panelWidthRatio: Float = 0.38f,
    val swipeLeftAction: String = "DELETE", // "DELETE", "ARCHIVE", "MARK_READ", "MUTE"
    val swipeRightAction: String = "PIN", // "PIN", "MARK_UNREAD", "FAVORITE"
    val sendOnEnter: Boolean = false,
    val enableSpamFilter: Boolean = true,
    val blockUnknownSenders: Boolean = false,
    val privatePasscode: String = "1234",
    val isPrivateLocked: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val hideNotificationPreview: Boolean = false,
    val fontScale: Float = 1.0f,
    val compactMode: Boolean = false,
    val aiAssistantEnabled: Boolean = true,
    val backupFrequency: String = "OFFLINE_ONLY"
)
