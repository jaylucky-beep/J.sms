package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val conversationId: Long,
    val sender: String,
    val recipient: String,
    val body: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isOutgoing: Boolean,
    val status: MessageStatus = MessageStatus.SENT,
    val isRead: Boolean = true,
    val attachmentUri: String? = null,
    val attachmentType: String? = null, // "IMAGE", "AUDIO", "FILE"
    val reaction: String? = null, // e.g., "❤️", "👍"
    val isScheduled: Boolean = false,
    val scheduledTime: Long? = null
)

enum class MessageStatus {
    SENDING,
    SENT,
    DELIVERED,
    FAILED
}
