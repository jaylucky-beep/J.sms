package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scheduled_messages")
data class ScheduledMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val recipient: String,
    val contactName: String = "",
    val body: String,
    val scheduledTimestamp: Long,
    val isSent: Boolean = false,
    val failureReason: String? = null
)
