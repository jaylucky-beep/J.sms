package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val email: String = "",
    val photoUri: String? = null,
    val isFavorite: Boolean = false,
    val isBlocked: Boolean = false,
    val avatarColorHex: String = "#3B82F6",
    val category: String = "Personal"
)
