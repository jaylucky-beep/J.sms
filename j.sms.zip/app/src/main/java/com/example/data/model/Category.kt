package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val colorHex: String = "#3B82F6",
    val iconName: String = "Folder",
    val isDefault: Boolean = false,
    val rulePattern: String = "" // Keyword matching rule
)
