package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class Conversation(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val address: String, // Phone number or contact identifier
    val contactName: String = "",
    val avatarUrl: String? = null,
    val lastMessage: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val isArchived: Boolean = false,
    val isSpam: Boolean = false,
    val isPrivate: Boolean = false,
    val isFavorite: Boolean = false,
    val draft: String = "",
    val categories: String = "Inbox", // Comma-separated list of categories e.g. "Inbox,Work messages"
    val avatarColorHex: String = "#8B5CF6", // Hex string for initial avatar background
    val themePreset: String = "Default" // Conversation specific theme
)
